import React from 'react';
import ReactDom from 'react-dom';
import { WeatherNews } from './WeatherNews';

ReactDom.render(<WeatherNews />, document.getElementById('app'));
